vnc4server -kill :0 && vnc4server :0 -geometry ${1:-1280x720}
